Image List:

All images are png files


d1, d2, d3 - Sliding window ranges

h1, h2, h3 - HOG of training data's sample image

hog1, hog2, hog3 - HOG of video frame

image0000 - sample training image - Car

image8 - sample training image - Not Car

t1 to t6 - Test images with output
